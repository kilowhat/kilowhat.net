<?php

/**
 * Performs a JSON request to Flarum Api
 * @param string $path
 * @param array $data
 * @return array|WP_Error
 */
function kilowhat_flarum_send_request($path, $data = [])
{
    $errors = new WP_Error();

    $url = get_option('kilowhat_flarum_url');

    if (empty($url)) {
        $errors->add('kilowhat_flarum_url', 'Flarum URL not configured in the settings');
    }

    $key = get_option('kilowhat_flarum_key');

    if (empty($key)) {
        $errors->add('kilowhat_flarum_key', 'Flarum Api Key not configured in the settings');
    }

    if ($errors->has_errors()) {
        wp_send_json_error($errors, 500);
    }

    $userId = get_option('kilowhat_flarum_user_id') ?: 1;

    $fullUrl = $url . '/api/kilowhat/wordpress/' . $path;

    $return = wp_remote_post($fullUrl, [
        'headers' => [
            'Authorization' => 'Token ' . $key . '; userId=' . $userId,
            'Content-Type' => 'application/json',
        ],
        'timeout' => 20,
        'body' => json_encode($data),
    ]);

    if (is_wp_error($return)) {
        wp_send_json_error($return, 500);
    }

    if ($return['response']['code'] !== 200) {
        wp_send_json_error(new WP_Error(
            'kilowhat_flarum_api_error',
            'Received status code ' . $return['response']['code'] . ' from Flarum API at ' . $fullUrl . '. Body: ' . $return['body']
        ), 500);
    }

    return $return;
}

/**
 * Creates a signed url signature
 * Implementation compatible with spatie/url-signer
 * @param string $url
 * @param int $expiration Unix timestamp
 * @return string
 */
function kilowhat_flarum_create_signature($url, $expiration)
{
    $key = get_option('kilowhat_flarum_key');

    if (empty($key)) {
        die('Missing Flarum Key');
    }

    return md5("{$url}::{$expiration}::{$key}");
}

/**
 * Signs a url with the default expiration and append the signature to it
 * @param string $url
 * @return string
 */
function kilowhat_flarum_sign_url($url)
{
    $expiration = time() + 60 * 5; // now + 5 minutes as timestamp

    $signature = kilowhat_flarum_create_signature($url, $expiration);

    return $url . '&expires=' . $expiration . '&signature=' . $signature;
}

/**
 * Verifies a url. Ends script execution in case of invalid signature or expiration
 * @param string $url
 */
function kilowhat_flarum_validate_url($url)
{
    $query = parse_url($url, PHP_URL_QUERY);
    parse_str($query, $params);

    $expiration = $params['expires'];
    $providedSignature = $params['signature'];

    if (empty($expiration) || empty($providedSignature)) {
        die('Invalid url signature, missing parameters');
    }

    unset($params['expires']);
    unset($params['signature']);

    if ($expiration < time()) {
        die('Expired url signature');
    }

    $newQuery = http_build_query($params);

    $intendedUrl = str_replace($query, $newQuery, $url);

    $validSignature = kilowhat_flarum_create_signature($intendedUrl, $expiration);

    if (!hash_equals($validSignature, $providedSignature)) {
        die('Invalid url signature');
    }
}

function kilowhat_flarum_post_uses_flarum_embed($post = null)
{
    if (!get_option('kilowhat_flarum_comments')) {
        return false;
    }

    $config = get_option('kilowhat_flarum_comments_post_types');
    $postTypes = explode(',', $config ?: 'post,page');

    return in_array(get_post_type($post), $postTypes);
}
