<?php

/**
 * Redirect to Flarum if user is already connected
 * Used if the user clicks login in Flarum but is already connected in WordPress
 */
add_action('login_form_login', function () {
    // If this is the Flarum login popup and WordPress is already connected, we set the Flarum cookie and redirect immediately
    if (
        isset($_REQUEST['redirect_to']) &&
        kilowhat_flarum_redirect_is_auth($_REQUEST['redirect_to']) &&
        get_option('kilowhat_flarum_sso')
    ) {
        $user = wp_get_current_user();

        if ($user instanceof WP_User && $user->exists()) {
            $return = kilowhat_flarum_send_request('user/login/' . $user->ID, [
                'username' => $user->user_login,
                'first_name' => $user->first_name,
                'last_name' => $user->last_name,
                'email' => $user->user_email,
                'bio' => $user->description,
            ]);

            $payload = json_decode($return['body'], true);

            wp_redirect(get_option('kilowhat_flarum_url') . '/auth/wordpress?continue=1&token=' . $payload['token']);
            exit();
        }
    }
});

/**
 * Perform login into Flarum via the Api
 * Set global Flarum remember cookie if the request won't be redirected to Flarum
 */
add_action('wp_login', function ($user_login, WP_User $user) {
    if (!get_option('kilowhat_flarum_sso')) {
        return;
    }

    $return = kilowhat_flarum_send_request('user/login/' . $user->ID, [
        'username' => $user->user_login,
        'email' => $user->user_email,
        'bio' => $user->description,
    ]);

    $payload = json_decode($return['body'], true);

    // If the redirect goes back to Flarum, we send the token in the url to avoid setting unnecessary cookies
    if (
        isset($_REQUEST['redirect_to']) && kilowhat_flarum_redirect_is_auth($_REQUEST['redirect_to']) ||
        // Add compatibility with "Nextend Social Login" that no longer has the redirect_to parameter in the url but stores it aside
        (class_exists(\NSL\Persistent\Persistent::class) && kilowhat_flarum_redirect_is_auth(\NSL\Persistent\Persistent::get('redirect')))
    ) {
        global $kilowhat_flarum_token;

        // Using a global variable to get this value inside the login_redirect hook
        $kilowhat_flarum_token = $payload['token'];
    } else {
        // if the request doesn't go back to Flarum, we set a global cookie that will auto-login the user if they visit the forum
        $domain = get_option('kilowhat_flarum_cookie_domain') ?: COOKIE_DOMAIN;

        setcookie('flarum_remember', $payload['token'], time() + 60 * 60 * 24, '/', $domain, is_ssl(), true);
    }
}, 10, 2);

/**
 * Add the Flarum url to allowed redirects for the login
 */
add_filter('allowed_redirect_hosts', function ($content) {
    $content[] = parse_url(get_option('kilowhat_flarum_url'), PHP_URL_HOST);
    return $content;
});

/**
 * Redirect to Flarum after successful login
 */
add_filter('login_redirect', function ($redirect_to, $requested_redirect_to, $user) {
    if (
        kilowhat_flarum_redirect_is_auth($redirect_to) &&
        get_option('kilowhat_flarum_sso') &&
        $user instanceof WP_User
    ) {
        // If $user is an instance of WP_User it means the authentication was successful

        // Global variable comes from the wp_login hook
        global $kilowhat_flarum_token;

        return get_option('kilowhat_flarum_url') . '/auth/wordpress?continue=1' .
            (isset($kilowhat_flarum_token) && $kilowhat_flarum_token ? '&token=' . $kilowhat_flarum_token : '');
    }

    // We return the value so it's added to the form and kept in subsequent requests
    return $redirect_to;
}, 10, 3);

/**
 * Adds compatibility with "Nextend Social Login" wordpress plugin that doesn't call the "login_redirect" hook
 * The filter is called two times, the first is to see if there ARE fixed redirects, second time is to apply them
 */
function kilowhat_flarum_nextend_social_login_redirect($redirect)
{
    if (!kilowhat_flarum_redirect_is_auth(\NSL\Persistent\Persistent::get('redirect'))) {
        return $redirect;
    }

    // Call our original logic
    $url = apply_filters('login_redirect', '/auth/wordpress', '', wp_get_current_user());

    if ($url === '/auth/wordpress') {
        // If we can't finish the login, return a default redirect url so the redirect isn't interpreted as a WP path
        return site_url();
    }

    return $url;
}

// There's no single hook, we have to add one for each provider of Nextend Social Login
add_filter('amazon_login_redirect_url', 'kilowhat_flarum_nextend_social_login_redirect');
add_filter('disqus_login_redirect_url', 'kilowhat_flarum_nextend_social_login_redirect');
add_filter('facebook_login_redirect_url', 'kilowhat_flarum_nextend_social_login_redirect');
add_filter('google_login_redirect_url', 'kilowhat_flarum_nextend_social_login_redirect');
add_filter('linkedin_login_redirect_url', 'kilowhat_flarum_nextend_social_login_redirect');
add_filter('paypal_login_redirect_url', 'kilowhat_flarum_nextend_social_login_redirect');
add_filter('twitter_login_redirect_url', 'kilowhat_flarum_nextend_social_login_redirect');
add_filter('vk_login_redirect_url', 'kilowhat_flarum_nextend_social_login_redirect');
add_filter('wordpress_login_redirect_url', 'kilowhat_flarum_nextend_social_login_redirect');
add_filter('yahoo_login_redirect_url', 'kilowhat_flarum_nextend_social_login_redirect');

/**
 * Hides the "back to blog" link in login modal
 */
add_action('login_footer', function () {
    if (isset($_REQUEST['redirect_to']) && kilowhat_flarum_redirect_is_auth($_REQUEST['redirect_to'])) {
        echo '<style>#backtoblog{display:none;}</style>';
    }
});

/**
 * Completely replaces the logout process to handle url signature check and redirects
 */
add_action('login_form_logout', function () {
    if (isset($_REQUEST['signature'])) {
        $fullUrl = 'http' . (is_ssl() ? 's' : '') . '://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];

        kilowhat_flarum_validate_url($fullUrl);
    } else {
        check_admin_referer('log-out');
    }

    $user = wp_get_current_user();

    wp_logout();

    if (!isset($_REQUEST['skip_flarum_logout'])) {
        $url = kilowhat_flarum_sign_url(get_option('kilowhat_flarum_url') . '/logout?skip_wordpress_logout=1&return=wordpress&wordpress_id=' . $user->ID);
        wp_redirect($url);
        exit();
    }

    if (!empty($_REQUEST['redirect_to'])) {
        $redirect_to = $requested_redirect_to = $_REQUEST['redirect_to'];
    } else {
        $redirect_to = 'wp-login.php?loggedout=true';
        $requested_redirect_to = '';
    }

    $redirect_to = apply_filters('logout_redirect', $redirect_to, $requested_redirect_to, $user);
    wp_safe_redirect($redirect_to);
    exit();
});
