<?php
/*
Plugin Name: Flarum Integration
Plugin URI: https://kilowhat.net/flarum/extensions/wordpress
Description: Integrate with Flarum login and comments
Author: Clark Winkelmann
Version: 1.5.0
Author URI: https://clarkwinkelmann.com/
*/

require_once(__DIR__ . '/kilowhat-flarum-methods.php');
require_once(__DIR__ . '/kilowhat-flarum-settings.php');
require_once(__DIR__ . '/kilowhat-flarum-embed.php');
require_once(__DIR__ . '/kilowhat-flarum-login.php');
require_once(__DIR__ . '/kilowhat-flarum-sync.php');
