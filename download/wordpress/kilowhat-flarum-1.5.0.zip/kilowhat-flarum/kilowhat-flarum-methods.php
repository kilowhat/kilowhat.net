<?php

/**
 * Performs a JSON request to Flarum Api
 * @param string $path
 * @param array $data
 * @return array|WP_Error
 */
function kilowhat_flarum_send_request($path, $data = [])
{
    $errors = new WP_Error();

    $url = get_option('kilowhat_flarum_url');

    if (empty($url)) {
        $errors->add('kilowhat_flarum_url', 'Flarum URL not configured in the settings');
    }

    $key = get_option('kilowhat_flarum_key');

    if (empty($key)) {
        $errors->add('kilowhat_flarum_key', 'Flarum Api Key not configured in the settings');
    }

    if ($errors->has_errors()) {
        wp_send_json_error($errors, 500);
    }

    $userId = get_option('kilowhat_flarum_user_id') ?: 1;

    $fullUrl = $url . '/api/kilowhat/wordpress/' . $path;

    $return = wp_remote_post($fullUrl, [
        'headers' => [
            'Authorization' => 'Token ' . $key . '; userId=' . $userId,
            'Content-Type' => 'application/json',
        ],
        'timeout' => 20,
        'body' => json_encode($data + [
                'meta' => [
                    'current_blog_id' => get_current_blog_id(),
                    'options' => [
                        'kilowhat_flarum_comments_post_types' => get_option('kilowhat_flarum_comments_post_types'),
                        'kilowhat_flarum_override_tags' => get_option('kilowhat_flarum_override_tags'),
                    ],
                ],
            ]),
    ]);

    if (is_wp_error($return)) {
        wp_send_json_error($return, 500);
    }

    if ($return['response']['code'] !== 200) {
        wp_send_json_error(new WP_Error(
            'kilowhat_flarum_api_error',
            'Received status code ' . $return['response']['code'] . ' from Flarum API at ' . $fullUrl . '. Body: ' . $return['body']
        ), 500);
    }

    return $return;
}

/**
 * Creates a signed url signature
 * Implementation compatible with spatie/url-signer
 * @param string $url
 * @param int $expiration Unix timestamp
 * @return string
 */
function kilowhat_flarum_create_signature($url, $expiration)
{
    $key = get_option('kilowhat_flarum_key');

    if (empty($key)) {
        die('Missing Flarum Key');
    }

    return md5("{$url}::{$expiration}::{$key}");
}

/**
 * Signs a url with the default expiration and append the signature to it
 * @param string $url
 * @return string
 */
function kilowhat_flarum_sign_url($url)
{
    $expiration = time() + 60 * 5; // now + 5 minutes as timestamp

    $signature = kilowhat_flarum_create_signature($url, $expiration);

    return $url . '&expires=' . $expiration . '&signature=' . $signature;
}

/**
 * Verifies a url. Ends script execution in case of invalid signature or expiration
 * @param string $url
 */
function kilowhat_flarum_validate_url($url)
{
    $query = parse_url($url, PHP_URL_QUERY);
    parse_str($query, $params);

    $expiration = $params['expires'];
    $providedSignature = $params['signature'];

    if (empty($expiration) || empty($providedSignature)) {
        die('Invalid url signature, missing parameters');
    }

    unset($params['expires']);
    unset($params['signature']);

    if ($expiration < time()) {
        die('Expired url signature');
    }

    $newQuery = http_build_query($params);

    $intendedUrl = str_replace($query, $newQuery, $url);

    $validSignature = kilowhat_flarum_create_signature($intendedUrl, $expiration);

    if (!hash_equals($validSignature, $providedSignature)) {
        die('Invalid url signature');
    }
}

function kilowhat_flarum_post_uses_flarum_embed($post = null)
{
    if (!get_option('kilowhat_flarum_comments')) {
        return false;
    }

    $config = get_option('kilowhat_flarum_comments_post_types');
    $postTypes = explode(',', $config ?: 'post,page');

    return in_array(get_post_type($post), $postTypes);
}

/**
 * Prepares a post to be sent to the /post/update endpoint of Flarum
 * @param WP_Post $post
 * @return array
 */
function kilowhat_wordpress_format_post_for_api($post)
{
    /**
     * @var $post WP_Post
     */
    $author = get_userdata($post->post_author);

    $terms = wp_get_object_terms($post->ID, [
        'post_tag',
        'category'
    ], [
        'fields' => 'all',
    ]);

    return [
        'comment_status' => $post->comment_status,
        'post_status' => $post->post_status,
        'url' => get_permalink($post),
        'title' => html_entity_decode(get_the_title($post)), // We don't want to send characters encoded as htmlentities
        'body' => apply_filters('the_content', $post->post_content),
        'type' => $post->post_type,
        'date_created' => $post->post_date_gmt,
        'date_updated' => $post->post_modified_gmt,
        'thumbnail_url' => get_the_post_thumbnail_url($post) ?: null,
        'author' => $author ? [
            'id' => $author->id,
            'display_name' => $author->display_name,
        ] : null,
        'terms' => is_array($terms) ? array_map(function ($term) {
            /**
             * @var $term WP_Term
             */
            return [
                'id' => $term->term_id,
                'name' => $term->name,
                'slug' => $term->slug,
                'taxonomy' => $term->taxonomy,
                'description' => $term->description,
            ];
        }, $terms) : null,
    ];
}

function kilowhat_flarum_redirect_is_auth($redirect_to)
{
    // Backward compatibility with pre-1.6 redirect logic
    if ($redirect_to === 'flarum-auth') {
        return true;
    }

    // We check just the end, that way we avoid reading the forum URL setting and improve performance
    // There is no security implication right now given we re-build the URL before returning the token anyway
    // However if we were to add the token to this URL, we'll need to check the host is whitelisted
    // Note in case of change: for simplicity the Nextend compatibility code passes just the path without the domain
    return substr($redirect_to, -15) === '/auth/wordpress';
}
