# Flarum Wordpress Integration

This is the Wordpress plugin that completes the Flarum extension.

To install, place the `kilowhat-flarum` folder inside `wp-content/plugins`.

Check out the full documentation at <https://kilowhat.net/flarum/extensions/wordpress>.
