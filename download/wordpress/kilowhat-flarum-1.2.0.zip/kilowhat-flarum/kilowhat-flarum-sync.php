<?php

/**
 * Lets Flarum authenticate in the Wordpress REST Api via the shared Api Key
 * Inspired by the application-passwords plugin
 */
add_action('determine_current_user', function ($input_user) {
    // Don't authenticate twice
    if (!empty($input_user)) {
        return $input_user;
    }

    // If no user passed via basic auth, return initial value
    if (!isset($_SERVER['PHP_AUTH_USER'])) {
        return $input_user;
    }

    $key = get_option('kilowhat_flarum_key');

    /**
     * When a key hasn't been set up key, we will allow basic HTTP authentication
     * This allows easy configuration from the wizard in Flarum
     * Once a Flarum Key is set, this feature will be disabled to prevent any unnecessary security risk
     * Based on https://github.com/WP-API/Basic-Auth
     */
    if (empty($key)) {
        $user = wp_authenticate($_SERVER['PHP_AUTH_USER'], $_SERVER['PHP_AUTH_PW']);

        if ($user instanceof WP_User) {
            return $user->ID;
        }

        return $input_user;
    }

    // if password (api key) incorrect, return initial value
    if ($_SERVER['PHP_AUTH_PW'] !== $key) {
        return $input_user;
    }

    $user = get_user_by('login', $_SERVER['PHP_AUTH_USER']);

    if ($user instanceof WP_User) {
        return $user->ID;
    }

    // If user not found, return initial value
    return $input_user;
});

/**
 * Add ability to update comment_count via the Api
 */
add_action('rest_pre_insert_post', function ($prepared_post, $request) {
    if (!empty($request['comment_count'])) {
        $prepared_post->comment_count = $request['comment_count'];
    }

    return $prepared_post;
}, 10, 2);

/**
 * Save comment_count value
 */
add_action('wp_insert_post_data', function ($data, $postarr) {
    if (isset($postarr['comment_count'])) {
        $data['comment_count'] = $postarr['comment_count'];
    }

    return $data;
}, 10, 2);

/**
 * Syncs post edit from Wordpress to Flarum
 */
add_action('post_updated', function ($post_ID, $post_after, $post_before) {
    if (!get_option('kilowhat_flarum_comments')) {
        return;
    }

    if (!kilowhat_flarum_post_uses_flarum_embed($post_after)) {
        return;
    }

    /**
     * @var $post_after WP_Post
     * @var $post_before WP_Post
     */
    $contentChanged = false;
    if (
        $post_after->post_name !== $post_before->post_name ||
        $post_after->post_title !== $post_before->post_title ||
        $post_after->post_content !== $post_before->post_content ||
        $post_after->post_author !== $post_before->post_author
    ) {
        $contentChanged = true;
    }

    if ($contentChanged ||
        $post_after->post_status !== $post_before->post_status ||
        $post_after->comment_status !== $post_before->comment_status
    ) {
        kilowhat_flarum_send_request('post/update/' . $post_ID, kilowhat_wordpress_format_post_for_api($post_after) + [
                'updated' => true,
                'content_changed' => $contentChanged,
            ]);
    }
}, 10, 3);

add_action('save_post', function ($post_ID, $post, $update) {
    // Post update is already handled via the post_updated hook, so we don't handle it here
    if ($update) {
        return;
    }

    if (!kilowhat_flarum_post_uses_flarum_embed($post)) {
        return;
    }

    if (!get_option('kilowhat_flarum_comments')) {
        return;
    }

    kilowhat_flarum_send_request('post/update/' . $post_ID, kilowhat_wordpress_format_post_for_api($post) + [
            'created' => true,
        ]);
}, 10, 3);

/**
 * Syncs post deletion from Wordpress to Flarum
 */
add_action('deleted_post', function ($post_id) {
    if (!get_option('kilowhat_flarum_comments')) {
        return;
    }

    if (!kilowhat_flarum_post_uses_flarum_embed($post_id)) {
        return;
    }

    // Also triggers for other post types like post revisions. These will just return a "200 not found" and be ignored by Flarum
    kilowhat_flarum_send_request('post/delete/' . $post_id);
});

/**
 * Syncs user edit from Wordpress to Flarum
 */
add_action('profile_update', function ($user_id, WP_User $old_user_data) {
    if (!get_option('kilowhat_flarum_sso')) {
        return;
    }

    $new_user = get_userdata($user_id);

    //TODO: check bio

    if (
        $new_user->user_email !== $old_user_data->user_email ||
        $new_user->description !== $old_user_data->description//TODO: do we get the new value because it's in the meta table?
    ) {
        kilowhat_flarum_send_request('user/update/' . $user_id, [
            'username' => $new_user->user_login,
            'first_name' => $new_user->first_name,
            'last_name' => $new_user->last_name,
            'email' => $new_user->user_email,
            'bio' => $new_user->description,
        ]);
    }
}, 10, 2);

/**
 * Syncs user deletion from Wordpress to Flarum
 */
add_action('deleted_user', function ($user_id) {
    if (!get_option('kilowhat_flarum_sso')) {
        return;
    }

    kilowhat_flarum_send_request('user/delete/' . $user_id);
});
