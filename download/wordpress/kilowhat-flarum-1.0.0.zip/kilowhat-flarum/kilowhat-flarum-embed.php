<?php

add_action('comments_template', function ($file) {
    if (get_option('kilowhat_flarum_comments')) {
        return __DIR__ . '/comments_template.php';
    }

    return $file;
});

/**
 * Prevents submitting normal comments when the Comments integration is enabled
 */
add_action('wp_is_comment_flood', function ($is_flood) {
    if (get_option('kilowhat_flarum_comments')) {
        return true;
    }

    return $is_flood;
});

/**
 * Custom message for when native comments are blocked
 */
add_action('comment_flood_message', function ($message) {
    if (get_option('kilowhat_flarum_comments')) {
        return 'Classic Wordpress comments are disabled. Visit the post to comment using Flarum.';
    }

    return $message;
});

/**
 * Force the query to always return 0 comments
 */
add_action('pre_get_comments', function (WP_Comment_Query $query) {
    // We do that by caching a result of zero comments the same way WP_Comment_Query::get_comments does
    $_args = wp_array_slice_assoc($query->query_vars, array_keys($query->query_var_defaults));
    unset($_args['fields']);
    $key = md5(serialize($_args));
    $last_changed = wp_cache_get_last_changed('comment');
    $cache_key = "get_comments:$key:$last_changed";
    wp_cache_add($cache_key, [
        'comment_ids' => [],
        'found_comments' => 0,
    ], 'comment');
});

/**
 * Remove comments from admin menu
 */
add_action('admin_menu', function () {
    global $menu;

    if (array_key_exists(25, $menu)) {
        unset($menu[25]);
    }
});
