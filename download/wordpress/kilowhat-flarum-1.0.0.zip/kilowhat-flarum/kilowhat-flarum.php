<?php
/*
Plugin Name: Flarum Integration
Plugin URI: https://kilowhat.net/
Description: Integrate with Flarum login and comments
Author: Clark Winkelmann
Version: 1.0.0
Author URI: https://clarkwinkelmann.com/
*/

require_once(__DIR__ . '/kilowhat-flarum-methods.php');
require_once(__DIR__ . '/kilowhat-flarum-settings.php');
require_once(__DIR__ . '/kilowhat-flarum-embed.php');
require_once(__DIR__ . '/kilowhat-flarum-login.php');
require_once(__DIR__ . '/kilowhat-flarum-sync.php');

add_action('pre_wp_update_comment_count_now', function () {
    if (!get_option('kilowhat_flarum_comments')) {
        return;
    }

    //TODO:keep?
    die('this should not happen');
});
