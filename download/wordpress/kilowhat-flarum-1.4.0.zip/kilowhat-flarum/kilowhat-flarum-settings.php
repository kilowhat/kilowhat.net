<?php

function kilowhat_flarum_register_settings()
{
    register_setting('general', 'kilowhat_flarum_url', ['show_in_rest' => true]);
    register_setting('general', 'kilowhat_flarum_key', ['show_in_rest' => true]);
    register_setting('general', 'kilowhat_flarum_user_id', ['show_in_rest' => true]);
    register_setting('general', 'kilowhat_flarum_sso', ['show_in_rest' => true]);
    register_setting('general', 'kilowhat_flarum_cookie_domain', ['show_in_rest' => true]);
    register_setting('general', 'kilowhat_flarum_comments', ['show_in_rest' => true]);
    register_setting('general', 'kilowhat_flarum_comments_post_types', ['show_in_rest' => true]);
}

/**
 * Registers the plugin settings for the API
 */
add_action('rest_api_init', 'kilowhat_flarum_register_settings');

/**
 * Registers the plugin settings for the admin panel
 */
add_action('admin_init', function () {
    kilowhat_flarum_register_settings();

    add_settings_section(
        'kilowhat_flarum_section',
        'Flarum Integration Settings',
        function () {
            ?>
            <p>
                If you just installed the plugin, visit your Flarum admin panel under the Wordpress tab and use the
                installation wizard.
                This will automatically fill the URL, key and user ID below.
            </p>
            <p>
                Most parameters for this plugin/extension can be found in the Flarum admin panel.
                Check the <a href="https://kilowhat.net/flarum/extensions/wordpress" target="_blank">online
                    documentation</a> for more details.
            </p>
            <?php
        },
        'general'
    );

    add_settings_field(
        'kilowhat_flarum_url_field',
        'Flarum URL',
        function () {
            $setting = get_option('kilowhat_flarum_url');
            ?>
            <input type="text" name="kilowhat_flarum_url" style="width: 40em;"
                   value="<?php echo isset($setting) ? esc_attr($setting) : ''; ?>" placeholder="https://example.com">
            <p class="description">The url to your Flarum homepage, starting with <code>https://</code> and without any
                ending slash (<code>/</code>). Example: <code>https://forum.example.com</code> or <code>https://example.com/forum</code>
            </p>
            <?php
        },
        'general',
        'kilowhat_flarum_section'
    );

    add_settings_field(
        'kilowhat_flarum_token_field',
        'Flarum API Key',
        function () {
            $setting = get_option('kilowhat_flarum_key');
            ?>
            <input type="text" name="kilowhat_flarum_key" style="width: 40em;"
                   value="<?php echo isset($setting) ? esc_attr($setting) : ''; ?>">
            <p class="description">You will find this value in the Flarum extension settings. Copy it here.</p>
            <?php
        },
        'general',
        'kilowhat_flarum_section'
    );

    add_settings_field(
        'kilowhat_flarum_user_id_field',
        'Flarum User ID',
        function () {
            $setting = get_option('kilowhat_flarum_user_id');
            ?>
            <input type="text" name="kilowhat_flarum_user_id"
                   value="<?php echo isset($setting) ? esc_attr($setting) : ''; ?>" placeholder="1">
            <p class="description">The ID of your admin user in Flarum. You can usually leave this value to 1 unless you
                deleted the original admin account.</p>
            <?php
        },
        'general',
        'kilowhat_flarum_section'
    );

    add_settings_field(
        'kilowhat_flarum_sso_field',
        'Enable SSO integration',
        function () {
            $setting = get_option('kilowhat_flarum_sso');
            ?>
            <input type="checkbox" name="kilowhat_flarum_sso"
                <?php echo isset($setting) && $setting ? 'checked' : ''; ?>>
            <p class="description">Make sure you also enable the SSO integration in the Flarum admin panel.</p>
            <?php
        },
        'general',
        'kilowhat_flarum_section'
    );

    add_settings_field(
        'kilowhat_flarum_cookie_domain_field',
        'Cookie domain',
        function () {
            $setting = get_option('kilowhat_flarum_cookie_domain');
            ?>
            <input type="text" name="kilowhat_flarum_cookie_domain"
                   value="<?php echo isset($setting) ? esc_attr($setting) : ''; ?>" placeholder="example.com">
            <p class="description">The domain on which to set the login cookies. Usually the second level of the domain,
                like <code>example.com</code>.</p>
            <?php
        },
        'general',
        'kilowhat_flarum_section'
    );

    add_settings_field(
        'kilowhat_flarum_comments_field',
        'Enable comments integration',
        function () {
            $setting = get_option('kilowhat_flarum_comments');
            ?>
            <input type="checkbox" name="kilowhat_flarum_comments"
                <?php echo isset($setting) && $setting ? 'checked' : ''; ?>>
            <p class="description">Make sure you also enable the comments integration in the Flarum admin panel.</p>
            <?php
        },
        'general',
        'kilowhat_flarum_section'
    );

    add_settings_field(
        'kilowhat_flarum_comments_post_types_field',
        'Comments post types',
        function () {
            $setting = get_option('kilowhat_flarum_comments_post_types');
            ?>
            <input type="text" name="kilowhat_flarum_comments_post_types"
                   value="<?php echo isset($setting) ? esc_attr($setting) : ''; ?>" placeholder="post,page">
            <p class="description">The post types for which the Flarum comments integration will be available, separated
                by commas. Defaults to posts and pages.</p>
            <?php
        },
        'general',
        'kilowhat_flarum_section'
    );
});
