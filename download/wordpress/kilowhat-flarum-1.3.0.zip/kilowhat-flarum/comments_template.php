<?php

$post = get_post();

if ($post && (comments_open($post) || $post->comment_count > 0)):
    $embedUrl = get_option('kilowhat_flarum_url') . '/wordpress-embed-by-post-id/' . $post->ID;
    ?>
    <div id="comments" class="comments-area">
        <iframe id="flarum-iframe" src="<?php echo esc_html($embedUrl); ?>" frameborder="0"
                style="width: 100%; min-height: 500px; height: 100vh; border: 1px solid #dedede;"></iframe>
    </div>
<?php
endif;
