<?php

add_action('comments_template', function ($file) {
    if (kilowhat_flarum_post_uses_flarum_embed()) {
        return __DIR__ . '/comments_template.php';
    }

    return $file;
});

add_shortcode('flarum_comments', function () {
    if (!get_post()) {
        return 'Wrong context for Flarum comments shortcode';
    }

    if (!kilowhat_flarum_post_uses_flarum_embed()) {
        return 'Flarum comments not enabled for this post type';
    }

    ob_start();
    require __DIR__ . '/comments_template.php';
    return ob_get_clean();
});

/**
 * Prevents submitting normal comments when the Comments integration is enabled
 */
add_action('wp_is_comment_flood', function ($is_flood) {
    if (kilowhat_flarum_post_uses_flarum_embed()) {
        return true;
    }

    return $is_flood;
});

/**
 * Custom message for when native comments are blocked
 */
add_action('comment_flood_message', function ($message) {
    if (kilowhat_flarum_post_uses_flarum_embed()) {
        return 'Classic Wordpress comments are disabled. Visit the post to comment using Flarum.';
    }

    return $message;
});

/**
 * Force the query to always return 0 comments
 */
add_action('pre_get_comments', function (WP_Comment_Query $query) {
    if (!kilowhat_flarum_post_uses_flarum_embed()) {
        return;
    }

    // We do that by caching a result of zero comments the same way WP_Comment_Query::get_comments does
    $_args = wp_array_slice_assoc($query->query_vars, array_keys($query->query_var_defaults));
    unset($_args['fields']);
    $key = md5(serialize($_args));
    $last_changed = wp_cache_get_last_changed('comment');
    $cache_key = "get_comments:$key:$last_changed";
    wp_cache_add($cache_key, [
        'comment_ids' => [],
        'found_comments' => 0,
    ], 'comment');
});

/**
 * Add an error if anything tries to call the comments update method of Wordpress
 */
add_action('pre_wp_update_comment_count_now', function ($count, $old, $postId) {
    if (!kilowhat_flarum_post_uses_flarum_embed($postId)) {
        return;
    }

    die('Flarum Wordpress integration error: a plugin is trying to update the comment count for a post managed by Flarum');
}, 10, 3);

/**
 * Remove comments from admin menu, but only in the default configuration (which usually means no native comments remaining)
 * Other plugins are not detected at this time (we might want to show the comments page when woocommerce is enabled for example)
 */
add_action('admin_menu', function () {
    global $menu;

    $postTypesSetting = get_option('kilowhat_flarum_comments_post_types') ?: 'post,page';

    if (get_option('kilowhat_flarum_comments') && $postTypesSetting === 'post,page' && array_key_exists(25, $menu)) {
        unset($menu[25]);
    }
});
