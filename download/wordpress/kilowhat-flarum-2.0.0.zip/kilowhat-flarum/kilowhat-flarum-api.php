<?php

function kilowhat_flarum_endpoint_authorize(WP_REST_Request $request): ?WP_Error
{
    $key = get_option('kilowhat_flarum_key');

    if (!$key) {
        return new WP_Error('kilowhat-flarum-missing-key', 'KILOWHAT Flarum integration error, key not set up', ['status' => 401]);
    }

    if ($key !== $request->get_header('X-Flarum-Key')) {
        return new WP_Error('kilowhat-flarum-invalid-key', 'KILOWHAT Flarum integration error, invalid key', ['status' => 401]);
    }

    return null;
}

function kilowhat_flarum_endpoint_get_user(WP_REST_Request $request)
{
    if ($authError = kilowhat_flarum_endpoint_authorize($request)) {
        return $authError;
    }

    $user = get_user_by('ID', (int)$request->get_param('id'));

    if ($user === false) {
        return new WP_Error('kilowhat-flarum-not-found', 'Post not found', ['status' => 404]);
    }

    return kilowhat_wordpress_format_user_for_api($user);
}

function kilowhat_flarum_endpoint_get_post(WP_REST_Request $request)
{
    if ($authError = kilowhat_flarum_endpoint_authorize($request)) {
        return $authError;
    }

    $post = get_post((int)$request->get_param('id'));

    if (is_null($post)) {
        return new WP_Error('kilowhat-flarum-not-found', 'Post not found', ['status' => 404]);
    }

    return kilowhat_wordpress_format_post_for_api($post) + [
            'uses_embed' => kilowhat_flarum_post_uses_flarum_embed($post),
        ];
}

function kilowhat_flarum_endpoint_update_post(WP_REST_Request $request)
{
    if ($authError = kilowhat_flarum_endpoint_authorize($request)) {
        return $authError;
    }

    $post_id = (int)$request->get_param('id');

    if ($request->has_param('comment_count')) {
        // Logic based on wp_update_comment_count_now
        wp_cache_delete('comments-0', 'counts');
        wp_cache_delete("comments-{$post_id}", 'counts');

        $post = get_post($post_id);

        global $wpdb;
        $wpdb->update($wpdb->posts, [
            'comment_count' => (int)$request->get_param('comment_count'),
        ], [
            'ID' => $post_id,
        ]);

        clean_post_cache($post);
    }

    if ($request->has_param('comment_status')) {
        // Set a global flag, so we don't report the change back to Flarum
        // It wouldn't really create any issue but that would be bad for performance
        global $kilowhatFlarumPostUpdatedInternal;
        $kilowhatFlarumPostUpdatedInternal = true;
        try {
            wp_update_post([
                'ID' => $post_id,
                'comment_status' => (string)$request->get_param('comment_status'),
            ]);
        } finally {
            $kilowhatFlarumPostUpdatedInternal = false;
        }
    }

    return [];
}

function kilowhat_flarum_endpoint_settings(WP_REST_Request $request)
{
    if ($authError = kilowhat_flarum_endpoint_authorize($request)) {
        return $authError;
    }

    $whitelist = [
        'kilowhat_flarum_url',
        'kilowhat_flarum_key',
        'kilowhat_flarum_user_id',
        'kilowhat_flarum_default_actor_id',
        'kilowhat_flarum_sso',
        'kilowhat_flarum_cookie_domain',
        'kilowhat_flarum_comments',
        'kilowhat_flarum_comments_post_types',
        'kilowhat_flarum_override_tags',
    ];

    if ($request->get_method() === 'GET') {
        $roles = [];

        foreach (wp_roles()->get_names() as $role => $name) {
            $roles[$role] = translate_user_role($name);
        }

        return get_options($whitelist) + [
                'url' => site_url(),
                'is_multisite' => is_multisite(),
                'network_id' => get_current_network_id(),
                'site_id' => get_current_blog_id(),
                'roles' => $roles,
            ];
    }

    $updated = [];

    foreach ($whitelist as $attribute) {
        if ($request->has_param($attribute)) {
            $value = $request->get_param($attribute);
            if (is_null($value)) {
                delete_option($attribute);
            } else {
                update_option($attribute, $value);
            }
            $updated[] = $attribute;
        }
    }

    return [
        'updated' => $updated,
    ];
}

function kilowhat_flarum_endpoint_setup(WP_REST_Request $request)
{
    $key = get_option('kilowhat_flarum_key');

    if ($key) {
        return new WP_Error('kilowhat-flarum-already-setup', 'Already Setup, clear shared key setting to start again', ['status' => 400]);
    }

    $user = wp_authenticate((string)$request->get_param('username'), (string)$request->get_param('password'));

    if (!($user instanceof WP_User)) {
        return new WP_Error('kilowhat-flarum-wrong-credentials', 'Invalid credentials', ['status' => 401]);
    }

    if (!user_can($user, 'administrator')) {
        return new WP_Error('kilowhat-flarum-not-admin', 'Not admin credentials', ['status' => 403]);
    }

    if ($request->has_param('url')) {
        update_option('kilowhat_flarum_url', (string)$request->get_param('url'));
    }

    if ($request->has_param('key')) {
        update_option('kilowhat_flarum_key', (string)$request->get_param('key'));
    }

    return [
        'url' => site_url(),
        'is_multisite' => is_multisite(),
        'user_id' => $user->ID,
    ];
}

function kilowhat_flarum_endpoint_frame_auth(WP_REST_Request $request)
{
    header('Content-Type: text/html');

    $url = get_option('kilowhat_flarum_url');
    $parsedUrl = parse_url($url);

    header('Content-Security-Policy: frame-ancestors ' . $parsedUrl['scheme'] . '://' . $parsedUrl['host']);

    $token = $_COOKIE['flarum_remember'] ?? '';

    if (!$token) {
        echo "<p>No token</p>\n";
    } else if (!get_option('kilowhat_flarum_sso')) {
        $token = '';
        echo "<p>SSO not enabled</p>\n";
    } else {
        echo "<p>Ready for login</p>\n";
    }

    // Reset global current user value
    // Because WordPress nonce logic hard-codes it to 0 (in rest_cookie_check_errors)
    // But it's safe to read the user without a nonce here since we only return data and not perform any action
    global $current_user;
    $current_user = null;
    $user = wp_get_current_user();

    $payload = [
        'token' => $token,
    ];

    if ($user && $user->exists()) {
        $payload['displayName'] = $user->display_name;
        $payload['avatarUrl'] = get_avatar_url($user);
    }

    // Always return the javascript, even if the feature is disabled
    // Because the Flarum code expects the iframe to load and respond, even negatively
    // Otherwise it will retry in a loop and this could contribute to a self-DOS
    // (though with window post messaging it shouldn't affect the server)
    ?>
    <script>
        var flarumUrl = new URL(<?= json_encode($url) ?>);
        window.addEventListener('message', (event) => {
            if (event.origin !== flarumUrl.origin) {
                return;
            }

            if (typeof event.data !== 'object' || !event.data.hasOwnProperty('ready')) {
                return;
            }

            window.parent.postMessage(<?= json_encode($payload) ?>, flarumUrl.origin);
        });
    </script>
    <?php
    exit();
}

add_action('rest_api_init', function () {
    register_rest_route('kilowhat-flarum', '/users/(?P<id>\d+)', [
        'methods' => 'GET',
        'callback' => 'kilowhat_flarum_endpoint_get_user',
    ]);
    register_rest_route('kilowhat-flarum', '/posts/(?P<id>\d+)', [
        'methods' => 'GET',
        'callback' => 'kilowhat_flarum_endpoint_get_post',
    ]);
    register_rest_route('kilowhat-flarum', '/posts/(?P<id>\d+)', [
        'methods' => 'POST',
        'callback' => 'kilowhat_flarum_endpoint_update_post',
    ]);
    register_rest_route('kilowhat-flarum', '/settings', [
        'methods' => ['GET', 'POST'],
        'callback' => 'kilowhat_flarum_endpoint_settings',
    ]);
    register_rest_route('kilowhat-flarum', '/setup', [
        'methods' => 'POST',
        'callback' => 'kilowhat_flarum_endpoint_setup',
    ]);
    register_rest_route('kilowhat-flarum', '/frame-auth', [
        'methods' => 'GET',
        'callback' => 'kilowhat_flarum_endpoint_frame_auth',
    ]);
});
