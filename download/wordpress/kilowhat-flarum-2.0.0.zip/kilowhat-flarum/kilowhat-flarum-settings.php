<?php

function kilowhat_flarum_register_settings()
{
    register_setting('general', 'kilowhat_flarum_url', ['show_in_rest' => true]);
    register_setting('general', 'kilowhat_flarum_key', ['show_in_rest' => true]);
    // The user_id setting is no longer used since version 2.0 of the plugin,
    // but we leave it registered so Flarum can copy the value to its own settings during migration
    register_setting('general', 'kilowhat_flarum_user_id', ['show_in_rest' => true]);
    register_setting('general', 'kilowhat_flarum_sso', ['show_in_rest' => true]);
    register_setting('general', 'kilowhat_flarum_comments', ['show_in_rest' => true]);
    register_setting('general', 'kilowhat_flarum_comments_post_types', ['show_in_rest' => true]);
    register_setting('general', 'kilowhat_flarum_override_tags', ['show_in_rest' => true]);
}

/**
 * Registers the plugin settings for the API
 */
add_action('rest_api_init', 'kilowhat_flarum_register_settings');

/**
 * Registers the plugin settings for the admin panel
 */
add_action('admin_init', function () {
    kilowhat_flarum_register_settings();

    add_settings_section(
        'kilowhat_flarum_section',
        'Flarum Integration Settings',
        function () {
            ?>
            <p>
                If you just installed the plugin, visit your Flarum admin panel under the WordPress tab and use the
                installation wizard.
                This will automatically fill the URL, key and user ID below.
            </p>
            <p>
                Most parameters for this plugin/extension can be found in the Flarum admin panel.
                Check the <a href="https://kilowhat.net/flarum/extensions/wordpress" target="_blank">online
                    documentation</a> for more details.
            </p>
            <?php
        },
        'general'
    );

    add_settings_field(
        'kilowhat_flarum_url_field',
        'Flarum URL',
        function () {
            $setting = get_option('kilowhat_flarum_url');
            ?>
            <input type="text" name="kilowhat_flarum_url" style="width: 40em;"
                   value="<?php echo isset($setting) ? esc_attr($setting) : ''; ?>" placeholder="https://example.com">
            <p class="description">The url to your Flarum homepage, starting with <code>https://</code> and without any
                ending slash (<code>/</code>). Example: <code>https://forum.example.com</code> or <code>https://example.com/forum</code>
            </p>
            <?php
        },
        'general',
        'kilowhat_flarum_section'
    );

    add_settings_field(
        'kilowhat_flarum_key_field',
        'Flarum Shared API Key',
        function () {
            $setting = get_option('kilowhat_flarum_key');
            ?>
            <input type="text" name="kilowhat_flarum_key" style="width: 40em;"
                   value="<?php echo isset($setting) ? esc_attr($setting) : ''; ?>">
            <p class="description">You will find this value in the Flarum extension settings. Copy it here.</p>
            <?php
        },
        'general',
        'kilowhat_flarum_section'
    );

    add_settings_field(
        'kilowhat_flarum_sso_field',
        'Enable SSO integration',
        function () {
            $setting = get_option('kilowhat_flarum_sso');
            ?>
            <input type="checkbox" name="kilowhat_flarum_sso"
                <?php echo isset($setting) && $setting ? 'checked' : ''; ?>>
            <p class="description">Make sure you also enable the SSO integration in the Flarum admin panel.</p>
            <?php
        },
        'general',
        'kilowhat_flarum_section'
    );

    add_settings_field(
        'kilowhat_flarum_comments_field',
        'Enable comments integration',
        function () {
            $setting = get_option('kilowhat_flarum_comments');
            ?>
            <input type="checkbox" name="kilowhat_flarum_comments"
                <?php echo isset($setting) && $setting ? 'checked' : ''; ?>>
            <p class="description">Make sure you also enable the comments integration in the Flarum admin panel.</p>
            <?php
        },
        'general',
        'kilowhat_flarum_section'
    );

    add_settings_field(
        'kilowhat_flarum_comments_post_types_field',
        'Comments post types',
        function () {
            $setting = get_option('kilowhat_flarum_comments_post_types');
            ?>
            <input type="text" name="kilowhat_flarum_comments_post_types"
                   value="<?php echo isset($setting) ? esc_attr($setting) : ''; ?>" placeholder="post,page">
            <p class="description">The post types for which the Flarum comments integration will be available, separated
                by commas. Defaults to posts and pages.</p>
            <?php
        },
        'general',
        'kilowhat_flarum_section'
    );

    add_settings_field(
        'kilowhat_flarum_override_tags_field',
        'Override Flarum discussion tags',
        function () {
            $setting = get_option('kilowhat_flarum_override_tags');
            ?>
            <input type="text" name="kilowhat_flarum_override_tags"
                   value="<?php echo isset($setting) ? esc_attr($setting) : ''; ?>">
            <p class="description">A list of Flarum tag slugs or IDs separated by commas. If defined, the tags setting
                in the Flarum extension will be ignored and the tags selected here will always be applied.</p>
            <?php
        },
        'general',
        'kilowhat_flarum_section'
    );
});
