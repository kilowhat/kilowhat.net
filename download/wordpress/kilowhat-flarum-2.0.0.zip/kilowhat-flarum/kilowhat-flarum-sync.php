<?php

/**
 * Syncs post edit from WordPress to Flarum
 */
add_action('post_updated', function ($post_ID, $post_after, $post_before) {
    if (!kilowhat_flarum_post_uses_flarum_embed($post_after)) {
        return;
    }

    // Don't sync to Flarum when the hook was triggered by our own code
    global $kilowhatFlarumPostUpdatedInternal;
    if ($kilowhatFlarumPostUpdatedInternal) {
        return;
    }

    /**
     * @var $post_after WP_Post
     * @var $post_before WP_Post
     */
    $contentChanged = false;
    if (
        $post_after->post_name !== $post_before->post_name ||
        $post_after->post_title !== $post_before->post_title ||
        $post_after->post_content !== $post_before->post_content ||
        $post_after->post_author !== $post_before->post_author
    ) {
        $contentChanged = true;
    }

    if ($contentChanged ||
        $post_after->post_status !== $post_before->post_status ||
        $post_after->comment_status !== $post_before->comment_status
    ) {
        kilowhat_flarum_send_request('post/update/' . $post_ID, kilowhat_wordpress_format_post_for_api($post_after) + [
                'updated' => true,
                'content_changed' => $contentChanged,
            ]);
    }
}, 10, 3);

add_action('added_post_meta', 'kilowhat_flarum_updated_post_meta', 10, 4);
add_action('updated_post_meta', 'kilowhat_flarum_updated_post_meta', 10, 4);
add_action('deleted_post_meta', 'kilowhat_flarum_updated_post_meta', 10, 4);

function kilowhat_flarum_updated_post_meta($mid, $post_ID, $meta_key, $value)
{
    if ($meta_key !== '_thumbnail_id') {
        return;
    }

    $post = get_post($post_ID);

    if (!kilowhat_flarum_post_uses_flarum_embed($post)) {
        return;
    }

    kilowhat_flarum_send_request('post/update/' . $post_ID, kilowhat_wordpress_format_post_for_api($post) + [
            'updated' => true,
        ]);
}

add_action('save_post', function ($post_ID, $post, $update) {
    // Post update is already handled via the post_updated hook, so we don't handle it here
    if ($update) {
        return;
    }

    if (!kilowhat_flarum_post_uses_flarum_embed($post)) {
        return;
    }

    kilowhat_flarum_send_request('post/update/' . $post_ID, kilowhat_wordpress_format_post_for_api($post) + [
            'created' => true,
        ]);
}, 10, 3);

/**
 * Syncs post deletion from WordPress to Flarum
 */
add_action('deleted_post', function ($post_id) {
    if (!kilowhat_flarum_post_uses_flarum_embed($post_id)) {
        return;
    }

    // Also triggers for other post types like post revisions. These will just return a "200 not found" and be ignored by Flarum
    kilowhat_flarum_send_request('post/delete/' . $post_id);
});

/**
 * Syncs user edit from WordPress to Flarum
 */
add_action('profile_update', function ($user_id, WP_User $old_user_data) {
    if (!get_option('kilowhat_flarum_sso')) {
        return;
    }

    $new_user = get_userdata($user_id);

    //TODO: check bio

    $oldRoles = implode(',', $old_user_data->roles);
    $newRoles = implode(',', $new_user->roles);

    if (
        $newRoles !== $oldRoles ||
        $new_user->user_email !== $old_user_data->user_email ||
        $new_user->description !== $old_user_data->description//TODO: do we get the new value because it's in the meta table?
    ) {
        kilowhat_flarum_send_request('user/update/' . $user_id, kilowhat_wordpress_format_user_for_api($new_user));
    }
}, 10, 2);

/**
 * Syncs user deletion from WordPress to Flarum
 */
add_action('deleted_user', function ($user_id) {
    if (!get_option('kilowhat_flarum_sso')) {
        return;
    }

    kilowhat_flarum_send_request('user/delete/' . $user_id);
});
