<?php

/**
 * Redirect to Flarum if user is already connected
 * Used if the user clicks login in Flarum but is already connected in WordPress
 */
add_action('login_form_login', function () {
    // If this is the Flarum login popup and WordPress is already connected, we set the Flarum cookie and redirect immediately
    if (
        isset($_REQUEST['redirect_to']) &&
        kilowhat_flarum_redirect_is_auth($_REQUEST['redirect_to']) &&
        get_option('kilowhat_flarum_sso')
    ) {
        $user = wp_get_current_user();

        if ($user instanceof WP_User && $user->exists()) {
            $return = kilowhat_flarum_send_request('user/login/' . $user->ID, kilowhat_wordpress_format_user_for_api($user));

            $payload = json_decode($return['body'], true);

            if (is_array($payload)) {
                // TODO: re-use or clear the previous token
                wp_redirect(kilowhat_flarum_url_with_query($_REQUEST['redirect_to'], [
                    'token' => $payload['token'],
                ]));
                exit();
            }
        }
    }
});

/**
 * Perform login into Flarum via the Api
 * Set global Flarum remember cookie if the request won't be redirected to Flarum
 */
add_action('wp_login', function ($user_login, WP_User $user) {
    if (!get_option('kilowhat_flarum_sso')) {
        return;
    }

    $return = kilowhat_flarum_send_request('user/login/' . $user->ID, kilowhat_wordpress_format_user_for_api($user));

    $payload = json_decode($return['body'], true);

    // A redirect part of the login from Flarum side in popup or new tab
    // Add compatibility with "Nextend Social Login" that no longer has the redirect_to parameter in the url but stores it aside
    $redirectProvidedToLoginPage = $_REQUEST['redirect_to'] ?? (class_exists(\NSL\Persistent\Persistent::class) ? \NSL\Persistent\Persistent::get('redirect') : '');

    // If the redirect goes back to Flarum, we send the token in the url to avoid setting unnecessary cookies
    // And also there are more login mechanism now, but we will always pass the token by redirect when a redirect is already being done
    if (kilowhat_flarum_redirect_is_auth($redirectProvidedToLoginPage)) {
        // Using a global variable to get this value inside the login_redirect hook
        global $kilowhat_flarum_redirect;

        $kilowhat_flarum_redirect = kilowhat_flarum_url_with_query($redirectProvidedToLoginPage, [
            'token' => $payload['token'],
        ]);
    } else if ($payload['redirect'] ?? '') {
        global $kilowhat_flarum_redirect;

        // If the Flarum login API endpoint returns a URL, it will have the token already included
        // This provides more flexibility in case we want to change how this works later
        // We already checked that the return URL provided to the login page doesn't go back to Flarum above
        $kilowhat_flarum_redirect = kilowhat_flarum_url_with_query($payload['redirect'], [
            'return' => $redirectProvidedToLoginPage ?: site_url(),
        ]);
    } else {
        setcookie('flarum_remember', $payload['token'], [
            // The TTL is very arbitrary and doesn't match with what a native flarum_remember cookie would have
            // It should be long enough so it doesn't expire before the user visits Flarum from this WordPress session
            // But also not too long so it doesn't stay on the system if the WordPress session expires
            'expires' => time() + 60 * 60 * 24,
            'path' => '/',
            // if the request doesn't go back to Flarum, we set a global cookie that will auto-login the user if they visit the forum
            'domain' => $payload['cookie_domain'] ?? COOKIE_DOMAIN,
            'secure' => true,//is_ssl(),
            'httponly' => true,
            'samesite' => $payload['cookie_samesite'] ?? 'Lax',
        ]);
    }
}, 10, 2);

/**
 * Add the Flarum url to allowed redirects for the login
 */
add_filter('allowed_redirect_hosts', function ($content) {
    $content[] = parse_url(get_option('kilowhat_flarum_url'), PHP_URL_HOST);
    return $content;
});

/**
 * Redirect to Flarum after successful login
 */
add_filter('login_redirect', function ($redirect_to, $requested_redirect_to, $user) {
    global $kilowhat_flarum_redirect;

    // If $user is an instance of WP_User it means the authentication was successful
    if (isset($kilowhat_flarum_redirect) && $kilowhat_flarum_redirect && $user instanceof WP_User) {
        return $kilowhat_flarum_redirect;
    }

    // We return the value so it's added to the form and kept in subsequent requests
    return $redirect_to;
}, 50, 3);

/**
 * Adds compatibility with "Nextend Social Login" WordPress plugin that doesn't call the "login_redirect" hook
 * The filter is called two times, the first is to see if there ARE fixed redirects, second time is to apply them
 */
function kilowhat_flarum_nextend_social_login_redirect($redirect)
{
    global $kilowhat_flarum_redirect;

    if (isset($kilowhat_flarum_redirect) && $kilowhat_flarum_redirect) {
        return $kilowhat_flarum_redirect;
    }

    return $redirect;
}

// There's no single hook, we have to add one for each provider of Nextend Social Login
add_filter('amazon_login_redirect_url', 'kilowhat_flarum_nextend_social_login_redirect');
add_filter('disqus_login_redirect_url', 'kilowhat_flarum_nextend_social_login_redirect');
add_filter('facebook_login_redirect_url', 'kilowhat_flarum_nextend_social_login_redirect');
add_filter('google_login_redirect_url', 'kilowhat_flarum_nextend_social_login_redirect');
add_filter('linkedin_login_redirect_url', 'kilowhat_flarum_nextend_social_login_redirect');
add_filter('paypal_login_redirect_url', 'kilowhat_flarum_nextend_social_login_redirect');
add_filter('twitter_login_redirect_url', 'kilowhat_flarum_nextend_social_login_redirect');
add_filter('vk_login_redirect_url', 'kilowhat_flarum_nextend_social_login_redirect');
add_filter('wordpress_login_redirect_url', 'kilowhat_flarum_nextend_social_login_redirect');
add_filter('yahoo_login_redirect_url', 'kilowhat_flarum_nextend_social_login_redirect');

/**
 * Hides the "back to blog" link in login modal
 */
add_action('login_footer', function () {
    if (isset($_REQUEST['redirect_to']) && kilowhat_flarum_redirect_is_auth($_REQUEST['redirect_to'])) {
        echo '<style>#backtoblog{display:none;}</style>';
    }
});

/**
 * Completely replaces the logout process to handle url signature check and redirects
 */
add_action('login_form_logout', function () {
    if (isset($_REQUEST['signature'])) {
        $fullUrl = 'http' . (is_ssl() ? 's' : '') . '://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];

        kilowhat_flarum_validate_url($fullUrl);
    } else {
        check_admin_referer('log-out');
    }

    $user = wp_get_current_user();

    wp_logout();

    // We will try to invalidate the remember token so keeping the cookie shouldn't be dangerous
    // But there are still a few situations where it might remain valid
    // (if you manage to log out from Flarum side while never visiting any Flarum page)
    // So we don't want to leave it in the browser in case this is a shared/public computer
    setcookie('flarum_remember', '', -1, '/', COOKIE_DOMAIN, is_ssl(), true);

    if (!isset($_REQUEST['skip_flarum_logout'])) {
        $params = [
            'skip_wordpress_logout' => 1,
            'return' => 'wordpress',
            'wordpress_id' => $user->ID,
        ];

        // Send the token along, so Flarum can end the session even if it never started in the first place
        // Required to properly log out the iframe method if the forum was never opened
        // Can't call it "token" as it would conflict with Flarum's logout CSRF system
        if ($_COOKIE['flarum_remember'] ?? '') {
            $params['remember_token'] = $_COOKIE['flarum_remember'];
        }

        $url = kilowhat_flarum_sign_url(kilowhat_flarum_url_with_query(get_option('kilowhat_flarum_url') . '/logout', $params));
        wp_redirect($url);
        exit();
    }

    if (!empty($_REQUEST['redirect_to'])) {
        $redirect_to = $requested_redirect_to = $_REQUEST['redirect_to'];
    } else {
        $redirect_to = 'wp-login.php?loggedout=true';
        $requested_redirect_to = '';
    }

    $redirect_to = apply_filters('logout_redirect', $redirect_to, $requested_redirect_to, $user);
    wp_safe_redirect($redirect_to);
    exit();
});
